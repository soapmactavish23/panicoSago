/*
 * JavaScript MD5 Demo JS
 * https://github.com/blueimp/JavaScript-MD5
 *
 * Copyright 2013, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * https://opensource.org/licenses/MIT
 */

/* global md5 */

/* eslint-disable strict */

;(function() {
  'use strict'

  var input = document.getElementById('input')
  document
    .getElementById('calculate')
    .addEventListener('click', function(event) {
      event.preventDefault()
      document.getElementById('result').value = md5(input.value)
    })
  input.value = '日本'
})()
